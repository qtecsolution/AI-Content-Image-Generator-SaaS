<div class="modal fade" id="show-modal" tabindex="-1" role="dialog" aria-labelledby="title" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content p-2 p-lg-3" >

            <div class="modal-header border-0" id="modal-header">
                <h5 class="modal-title border-bottom w-100 pb-3" id="title">@translate(Confirmation)</h5>
            </div>

            <div class="modal-body" id="show-form">
                <p>@translate(Action confirmation message)</p>
            </div>
        </div>
    </div>
</div>
