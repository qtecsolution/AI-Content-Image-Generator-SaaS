@extends('errors::errorLayout')
@section('title', __('Content Not Found'))
@section('code', '404 - Not Found')