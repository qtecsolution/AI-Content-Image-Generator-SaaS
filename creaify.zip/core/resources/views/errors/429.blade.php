@extends('errors::errorLayout')
@section('title', __('Something went wrong'))
@section('code', '429 - Too Many Requests')

