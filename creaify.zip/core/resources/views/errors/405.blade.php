@extends('errors::errorLayout')
@section('title', __('Method Not Allow'))
@section('code', '405 - Method Not Allow')