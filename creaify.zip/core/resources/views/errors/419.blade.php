<script>
    history.go(-1);
</script>