<?php $__env->startSection('content'); ?>
    <!-- ===================hero  start======================= -->
    <section class="hero bg-blog pb-4">
        <div class="container">
            <div class="row g-4">
                <div class="col-12">
                    <div class="hero-content pt-5">
                        <h1 class="hero-title">Welcome to the  <br>
                            <span class="logo-name"><?php echo e(readConfig('name')); ?></span> blog
                            </h1>
                        <p class="hero-des"><?php echo e(readConfig('name')); ?> is designed to help you streamline your writing process, <br>
                            increase your productivity, and create high-quality content.</p>
                    </div>
                </div>

            

            </div>
        </div>
    </section>

    <!-- ===================hero end ======================= -->

    <!-- ===================blogs================= -->
    <section class="blog">
        <div class="container">


            <!-- cards -->
            <div class="row m-0">

                  <!-- blog category buttons -->

                  <ul class="category-list">
                    <li class="category-list-item <?php echo e(Route::currentRouteName() == 'blogs.index' ? 'active' : 'rumon'); ?>"><a href="<?php echo e(route('blogs.index')); ?>" class="category-list-link">All</a></li>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="category-list-item <?php echo e(Request::url() == route('blog.category',$cat->slug)  ? 'active' : 'rumon'); ?>">
                        <a href="<?php echo e(route('blog.category',$cat->slug)); ?>" 
                            class="category-list-link "><?php echo e($cat->name); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </ul>
          
            <!-- blog category cards -->

                <div class="blog-cards">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>" class="blog-category-card">
                        <figure class="blog-thumb">
                            <img src="<?php echo e(filePath($blog->image)); ?>" alt="">
                        </figure>
                        <div class="right">
                            <p class="date"><?php echo e(date('jS F, Y',strtotime($blog->created_at))); ?></p>
                            <h2 class="titel"><?php echo e($blog->title); ?></h2>
                            <p class="content"><?php echo e($blog->meta_description); ?> ...read more</p>
                            

                            <div class="blogcard-footer d-flex justify-content-end"> 
                                <button class="go-btn">
                                    <svg width="16" height="16" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.8125 9H15.1875" stroke="#2C4CAC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M10.125 3.9375L15.1875 9L10.125 14.0625" stroke="#2C4CAC" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg> 
                                </button>
                            </div>
                        </div>
                    </a>

                       
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- next previous images  -->
                <div class="buttons d-flex align-items-center gap-3 justify-content-center py-3 py-lg-5 blog-pagination">
                    <?php echo e($blogs->links('vendor.pagination.simple-bootstrap-5')); ?>

                </div>

            </div>
        </div>
    </section>
    <!-- ===================blogs================= -->

    <!--===================== faq  start=====================-->
    <section class="faq">
        <div class="container">

            <div class="row g-4 align-items-center">

                <div class="col-12" data-aos="fade-up" data-aos-duration="1000">
                    <div class="section-header">
                        <button class="section-btn"><span class="text">Faq</span></button>
                        <h3 class="benifits-title"> Frequently Asked <br>
                            Questions </h3>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="accordion" id="faqAccordion">
                        <!-- accordion item  -->
                        <?php $__currentLoopData = $allFaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqIndex => $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="heading-<?php echo e($faq->id); ?>">
                                <button class="accordion-button <?php if($faqIndex>0): ?> collapsed <?php endif; ?>" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#faqCollapse-<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="faqCollapse-<?php echo e($faq->id); ?>">
                                    <?php echo e($faq->question); ?>

                                </button>
                            </h2>
                            <div id="faqCollapse-<?php echo e($faq->id); ?>" class="accordion-collapse collapse <?php if($faqIndex==0): ?> show <?php endif; ?>" aria-labelledby="heading-<?php echo e($faq->id); ?>"
                                data-bs-parent="#faqAccordion">
                                <div class="accordion-body">
                                    <div class="card-divider-faq"></div>
                                    <p> <?php echo e($faq->answear); ?> </p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--===================== faq  end=====================-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/frontend/blog.blade.php ENDPATH**/ ?>