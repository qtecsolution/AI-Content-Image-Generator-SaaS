<?php $__env->startSection('title', 'Transaction Details'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Transaction Details</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content p-2 p-md-4 pt-0">
        <div class="row g-4">

            <div class="col-md-12">
                <div class="my-projects">
                    <div class="my-projects-header border-bottom">
                        <h5 class="header-title">Plan Purchase and expenses Informations</h5>
                    </div>

                    <div class="my-projects-body mt-4">
                        <div class="row g-4 g-4">
                            <?php if(!$order->is_paid): ?>
                            <h4 class="text-warning mt-5"> Admin authorization is necessary for this order. </h3>
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('order.approved', $order->id)); ?>"
                                        data-bs-toggle="tooltip" data-bs-title="Approve this order."  class="status-approved">Approve</a>
                                </div>
                            
                            <?php endif; ?>
                            <div class="col-lg-4">
                                <div class="purches-info-box pe-lg-4">
                                    <h4 class="title">Plan Information</h4>
                                    <ul class="purchesinfo-list">
                                        <li>Name: <?php echo e($plan->name); ?></li>
                                        <li>Word Count: <?php echo e($plan->word_count); ?></li>
                                        <li>API Call: <?php echo e($plan->call_api_count); ?> /mo </li>
                                        <li>Document Save Count: <?php echo e($plan->documet_count); ?> /mo</li>
                                        <li>Image Save Count: <?php echo e($plan->image_count); ?> /mo</li>
                                        <li>Monthly Price: <?php echo e(readConfig('currency_sambol')); ?><?php echo e($plan->price); ?></li>
                                        <li>Yearly Price: <?php echo e(readConfig('currency_sambol')); ?><?php echo e($plan->yearly_price); ?></li>
                                    </ul>
                                </div>    
                            </div>   
                            <div class="col-lg-4">
                                <div class="purches-info-box pe-lg-4">
                                    <h4 class="title">Purchase Information</h4>
                                    <ul class="purchesinfo-list">
                                        <li>Date: <?php echo e(dateTimeFormat($order->created_at)); ?></li>
                                        <li>Invoice: <?php echo e($order->invoice); ?></li>
                                        <li>Payment Type: <?php echo e($order->type==2?'Yearly':'Monthly'); ?></li>
                                        <li>Paid Amount: <?php echo e(readConfig('currency_sambol')); ?> <?php echo e($order->total); ?> </li>
                                        <li>Payment Method: <?php echo e($order->payment_method); ?></li>
                                        <?php if($order->other != ''): ?>
                                        <li> <b> Attachment: </b>  <a href="<?php echo e(filePath($order->other)); ?>" target="_blank"> <i class="fa fa-file"></i> Attach File </a> </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>    
                            </div>   
                            <div class="col-lg-4">
                                <?php if($expense != null): ?>
                                <div class="purches-info-box pe-lg-4">
                                    <h4 class="title">Expenses summary</h4>
                                    <ul class="purchesinfo-list">
                                        <li>Total API Call: <?php echo e($expense->current_api_count); ?></li>
                                            <li>Rest of API Call:
                                                <?php echo e($expense->call_api_count - $expense->current_api_count); ?></li>
                                            <li>Total Document Save Count:
                                                <?php echo e($expense->current_documet_count); ?>

                                            </li>
                                            <li>Rest of Documet Save Count:
                                                <?php echo e($expense->documet_count - $expense->current_documet_count); ?></li>
                                            <li>Total Image: <?php echo e($expense->current_image_count); ?>

                                            </li>
                                            <li>Rest of Image:
                                                <?php echo e($expense->image_count - $expense->current_image_count); ?></li>
                                            <li>Activated Date:
                                                <?php echo e(dateTimeFormat($expense->activated_at)); ?></li>
                                            <li>Expire Date:
                                                <?php echo e(dateTimeFormat($expense->expire_at)); ?></li>
                                    </ul>
                                </div>
                                
                                <?php endif; ?>    
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/admin/plan/expense.blade.php ENDPATH**/ ?>