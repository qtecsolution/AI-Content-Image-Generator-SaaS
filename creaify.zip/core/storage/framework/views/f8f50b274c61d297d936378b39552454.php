<?php $__env->startSection('title', __('Method Not Allow')); ?>
<?php $__env->startSection('code', '405 - Method Not Allow'); ?>
<?php echo $__env->make('errors::errorLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/errors/405.blade.php ENDPATH**/ ?>