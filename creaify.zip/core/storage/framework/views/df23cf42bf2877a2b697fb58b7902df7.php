<?php $__env->startSection('title','Profile'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"> Profile</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content p-2 p-md-4 pt-0">
        <div class="">

            <div class="col-md-12">
                <div class="my-projects">
                    <div class="my-projects-header border-bottom">
                        <h5 class="header-title text-capitalize"> Profile </h5>
                    </div>
                    <div class="my-projects-body">
                        <div class="row mt-3 g-2 ">
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="p-2">
                                        <?php if($user->avatar != '' && file_exists($user->avatar)): ?>
                                            <img src="<?php echo e(asset($user->avatar)); ?>" alt="<?php echo e($user->name); ?>"
                                                style="max-width:150px" class="rounded">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('assets/images/placeholder.png')); ?>"
                                                alt="<?php echo e($user->name); ?>" style="max-width:150px">
                                        <?php endif; ?>
                                    </div>
                                    <div class="card-body">
                                        <h5 class="card-title"> <?php echo e($user->name); ?> </h5>
                                    </div>
                                    <ul class="list-group list-group-flush info-list">
                                        <li class="list-group-item"> <b> Email: </b> <?php echo e($user->email); ?> </li>
                                        <li class="list-group-item"> <b> Phone: </b> <?php echo e($user->phone); ?> </li>
                                        <li class="list-group-item"> <b> Address: </b> <?php echo e($user->address ?? ''); ?> </li>
                                        <?php if($user->type == 'user'): ?>
                                            <li class="list-group-item"> <b> Plan: </b> <?php echo e($user->plan->name ?? ''); ?></li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-6 border-none border-lg-start">
                                <form method="POST" action="<?php echo e(route('profile.update')); ?>"
                                    enctype="multipart/form-data" class="authentication-form needs-validation">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">

                                    <div class="authentication-form-body">

                                        <!-- Name   -->
                                        <div class="form-group mb-3">
                                            <label for="name" class="form-label">Name *</label>
                                            <input id="name" type="text"
                                                class="form-control custom-input <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="name" value="<?php echo e($user->name); ?>" required
                                                placeholder="Enter your name" autocomplete="name" autofocus>

                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                        <!-- Email    -->
                                        <div class="form-group mb-3">
                                            <label for="email" class="form-label">Email* </label>
                                            <input id="email" type="email" readonly
                                                class="form-control custom-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="email" value="<?php echo e($user->email); ?>" required autocomplete="email"
                                                placeholder="Enter your Email">

                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="phone" class="form-label">Phone* </label>
                                            <input id="phone" type="tel"
                                                class="form-control custom-input <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="phone" value="<?php echo e($user->phone); ?>" required
                                                placeholder="Enter your phone">

                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="address" class="form-label">Address </label>
                                            <input id="address" type="tel"
                                                class="form-control custom-input <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="address" value="<?php echo e($user->address); ?>"
                                                placeholder="Enter your address">

                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label for="avatar" class="form-label"> New Avatar </label>
                                            <input id="avatar" type="file"
                                                class="form-control custom-input <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="avatar" value="<?php echo e(old('avatar')); ?>">

                                            <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="generate-btn-wrapper">
                                            <button type="submit" class="generate-btn">Update</button>
                                        </div>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/user/profile/profile.blade.php ENDPATH**/ ?>