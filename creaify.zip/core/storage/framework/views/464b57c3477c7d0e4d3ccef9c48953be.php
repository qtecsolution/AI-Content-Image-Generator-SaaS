<form action="<?php echo e(route('plan.purchase.store')); ?>" enctype="multipart/form-data" method="post" id="order_payment_done"
    class="mt-4" data-stripe-publishable-key="<?php echo e(readConfig('STRIPE_KEY')); ?>">
    <?php echo csrf_field(); ?>

    
    <input type="hidden" name="plan_id" value="<?php echo e($plan->id); ?>">
    <input type="hidden" id="paymentMethod" name="paymentMethod" value="stripe">
    <input type="hidden" id="paymentType" name="type" value="<?php echo e($type); ?>">
    <input type="hidden" id="paymentAmount" name="paymentAmount" value="<?php echo e($type == 2 ? $plan->yearly_price : $plan->price); ?>">
    <input type="hidden" id="paymentTID" name="paymentTID" value="">
    <input type="hidden" id="value_1" name="value_1" value="">



    <div class="form-group">
        <label for="name" class="form-label">Name</label>
        <input type="text" value="<?php echo e($user->name); ?>" class="form-control custom-input shadow-none" id="name"
            name="name" autocomplete="off" placeholder="Enter your name">
        <div class="valid-feedback">
            Awesome! You're one step closer to greatness.
        </div>
        <div class="invalid-feedback">
            Please enter your name
        </div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong> Please enter your name </strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group">
        <label for="phone" class="form-label">Email
        </label>
        <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control custom-input shadow-none"
            id="phone" autocomplete="off" placeholder="Enter your phone">
        <div class="valid-feedback">
            Awesome! You're one step closer to greatness.
        </div>
        <div class="invalid-feedback">
            Please enter your email
        </div>


    </div>

    <div class="form-group">
        <label for="address" class="form-label">Address </label>
        <input type="text" value="<?php echo e($user->address); ?>" class="form-control custom-input shadow-none" name="address"
            id="address" autocomplete="off" placeholder="Enter your address">
        <div class="valid-feedback">
            Awesome! You're one step closer to greatness.
        </div>
        <div class="invalid-feedback">
            Please enter your address
        </div>


    </div>




    <div class="form-group">
        <label for="phone" class="form-label">Phone
        </label>
        <input type="tel" class="form-control custom-input shadow-none" id="phone" autocomplete="off"
            placeholder="Enter your phone" name="phone" value="<?php echo e($user->phone); ?>">
        <div class="valid-feedback">
            Awesome! You're one step closer to greatness.
        </div>
        <div class="invalid-feedback">
            Please enter your Phone
        </div>

    </div>
</form>
<?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/user/purchase/stripePay.blade.php ENDPATH**/ ?>