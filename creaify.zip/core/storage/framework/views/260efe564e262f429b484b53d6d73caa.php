<?php $__env->startSection('content'); ?>
<form method="POST" class="authentication-form needs-validation" action="<?php echo e(route('password.email')); ?>">
    <?php echo csrf_field(); ?>
    <div class="authentication-form-header">
        <h3 class="logo-name"><?php echo e(readConfig('type_name')); ?></h3>
        <h3 class="section-title">Enter your valid email</h3>
        <p class="form-des">Forget Your Password! Please enter your email here. </p>
    </div>

    <div class="authentication-form-body">
        <!-- Email    -->
        <div class="form-group">
            <label for="email" class="form-label">Email<span class="text-danger">*</span> :</label>
            <input type="email" class="form-control custom-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email"
                name="email" value="<?php echo e(old('email')); ?>" required autocomplete="off" placeholder="Enter your Email">
            <div class="valid-feedback">
                Awesome! You're one step closer to greatness.
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="gradient-btn"> Send Reset Link </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>