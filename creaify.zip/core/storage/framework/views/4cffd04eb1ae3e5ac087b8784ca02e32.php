<?php $__env->startSection('content'); ?>
    <section class="blog-detail">
        <div class="container">
            <div class="row g-4 justify-content-center">
                <div class="col-lg-12">
                    <figure class="blog-detail-image">
                        <img src="<?php echo e(filePath($blog->image)); ?>" alt="blogdetail" height="864">
                    </figure>
                </div>
                <div class="col-lg-9">
                    <div class="blogdetail-row">


                        <div class="content">
                            <p class="date">
                                <span class="icon">
                                    <img src="<?php echo e(asset('assets/icons/calendar.svg')); ?>">
                                </span>
                                <?php echo e(date('jS F, Y', strtotime($blog->created_at))); ?>

                                <?php if($blog->category != null): ?>
                                <a href="<?php echo e(route('blog.category',$blog->category->slug)); ?>" class="mx-3">
                                <span class="icon">
                                    <img src="<?php echo e(asset('assets/icons/folder.svg')); ?>">
                                </span>
                                <?php echo e($blog->category->name ?? ''); ?>

                                </a>
                                <?php endif; ?>
                            </p>

                            <h1 class="blog-title"> <?php echo e($blog->title); ?> </h1>

                            <div class="top-content">
                                <?php echo $blog->description ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // blog scroll 

        // get all the links in the table of contents
        const tocLinks = document.querySelectorAll('.toclist-link');

        // for each link, add a scroll event listener
        tocLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                // prevent the default behavior of the link
                e.preventDefault();

                // get the target section's ID from the link's href attribute
                const targetId = link.getAttribute('href');

                // get the corresponding section element
                const targetSection = document.querySelector(targetId);

                // scroll to the target section
                targetSection.scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // add a scroll event listener to the window
        // add a scroll event listener to the window
        window.addEventListener('scroll', () => {
            // get the current scroll position
            const scrollPosition = window.scrollY;

            // loop through all the section elements
            const sections = document.querySelectorAll('div[id^="section-"]');
            sections.forEach(section => {
                // get the section's top and bottom positions relative to the viewport
                const sectionTop = section.offsetTop - 100;
                const sectionBottom = sectionTop + section.offsetHeight;

                // get the corresponding link element
                const link = document.querySelector(`.toclist-link[href="#${section.id}"]`);

                // get the parent li element of the link
                const parentLi = link.parentElement;

                // if the scroll position is within the section's bounds, add the "active" class to the parent li element
                if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
                    parentLi.classList.add('active');
                } else {
                    parentLi.classList.remove('active');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/frontend/blogDetails.blade.php ENDPATH**/ ?>