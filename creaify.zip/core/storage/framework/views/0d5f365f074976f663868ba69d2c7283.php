<?php $__env->startSection('title','Use Case Templates'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active"> Use Case Templates</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content p-2 p-md-4 pt-0">
    <div class="row ">

        <div class="col-md-12">
            <div class="my-projects all-templates">
                <div class="my-projects-header border-bottom">
                    <h5 class="header-title text-capitalize"> Use Case Templates </h5>
                </div>
                <div class="my-projects-body">
                    <div class="row gy-2">
                        <div class="col-md-12">
                            <ul class="category-list">
                                <li class="category-list-item <?php echo e((Route::currentRouteName() == 'user.templates' && !request()->input('cat')) ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('user.templates')); ?>" class="category-list-link py-2">All</a>
                                </li>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="category-list-item <?php echo e(Request::url() == route('user.templates') && request()->input('cat')==$cat->slug ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('user.templates')."?cat=$cat->slug"); ?>"
                                            class="category-list-link py-2 "><?php echo e($cat->name); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                            <a href="<?php echo e(route('content.create')); ?>?case=<?php echo e($case->id); ?>" class="template-card">
                                <figure class="card-img">
                                    <img src="<?php echo e(filePath($case->icon)); ?>" alt="<?php echo e($case->title); ?>">
                                </figure>
                                <h3 class="card-title"> <?php echo e($case->title); ?> </h3>
                                <p class="card-des"><?php echo e($case->details); ?></p>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/user/templates/index.blade.php ENDPATH**/ ?>