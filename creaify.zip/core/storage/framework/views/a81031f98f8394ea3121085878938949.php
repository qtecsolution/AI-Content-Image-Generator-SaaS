<div class="card-body">
    <form action="<?php echo e(route('pages.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group mb-3">
            <label  class="form-label">Page Title <span class="text-danger">*</span></label>
            <input class="form-control custom-input" placeholder="Page Title" type="text"  name="title" required>
        </div>

        

        <div class="form-group mb-3">
            <label class="form-label">Meta Keywords</label>
            <input class="form-control custom-input" name="meta_keys" type="text" max="100" placeholder="Meth Keys">
        </div>

        <div class="form-group mb-3">
            <label class="form-label">Meta Description</label>
            <textarea class="form-control custom-input" name="meta_desc" maxlength="200" placeholder="Meta Description write"></textarea>
        </div>
        

        
        <div class="generate-btn-wrapper">
            <button type="submit" class="generate-btn px-4">Create</button>
         </div>

    </form>
</div>





<?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/page/create.blade.php ENDPATH**/ ?>