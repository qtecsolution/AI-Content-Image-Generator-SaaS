<?php $__env->startSection('title', 'Transactions'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item">Transactions</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content p-2 p-md-4 pt-0">
        <div class="row g-4">
            <div class="col-md-12">
                <div class="my-projects">
                    <div class="my-projects-header border-bottom mb-3">
                        <h5 class="header-title">My Transactions</h5>
                        <div class="project-button pull-right">
                        </div>
                    </div>
                    <div class="my-projects-body">

                        <div class="project-table-wrapper p-3">

                            <table class="project-table table">
                                <thead>
                                    <tr class="bg-white">
                                        <td>Date</td>
                                        <td>Invoice</td>
                                        <td>User</td>
                                        <td>Plan</td>
                                        <td>Method</td>
                                        <td width="10%"></th>
                                    </tr>
                                </thead>
                                <body>
                                    <?php $__currentLoopData = $allData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(dateTimeFormat($data->created_at)); ?></td>
                                        <td> <?php echo e($data->invoice); ?> </td>
                                        <td> <?php echo e($data->user->name); ?> </td>
                                        <td> <?php echo e($data->plan->name); ?> </td>
                                        <td> <?php echo e($data->payment_method); ?> </td>
                                        <td> 
                                            <?php if($data->is_paid): ?>
                                            <a href="<?php echo e(route('user.transactions.details', $data->id)); ?>"
                                                class="status-expenses">Expenses</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('user.transactions.details', $data->id)); ?>" class="status-panding">Pending</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </body>
                            </table>
                        </div>
                        <div class="row g-2">
                            <div class="col mt-3">
                                <?php echo e($allData->links('vendor.pagination.default')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/user/purchase/transactions.blade.php ENDPATH**/ ?>