<script>
    history.go(-1);
</script><?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/errors/419.blade.php ENDPATH**/ ?>