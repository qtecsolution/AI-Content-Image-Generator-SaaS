<div class="card-body">
    <form action="<?php echo e(route('pages.update')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($page->id); ?>">
        <div class="form-group mb-3">
            <label class="form-label">Page Title <span class="text-danger">*</span></label>
            <input class="form-control custom-input" type="text" name="title" value="<?php echo e($page->title); ?>" required>
        </div>


        

        <div class="form-group mb-3">
            <label class="form-label">Meta Keywords</label>
            <input class="form-control custom-input" name="meta_keys" value="<?php echo e($page->meta_keys); ?>" type="text" max="100" placeholder="Meth Keys">

        </div>

        <div class="form-group mb-3">
            <label class="form-label">Meta Description</label>
            <textarea class="form-control custom-input" name="meta_desc" maxlength="200" placeholder="Meta Description write"><?php echo strip_tags($page->meta_desc); ?></textarea>
           
        </div>
       


        <div class="float-right">
            <button class="btn btn-primary px-5 radius-30" type="submit">Save</button>
        </div>

    </form>
</div>
<?php /**PATH /opt/lampp/htdocs/creaify/core/resources/views/page/edit.blade.php ENDPATH**/ ?>